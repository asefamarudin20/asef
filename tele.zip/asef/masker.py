# import the packages
from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
from tensorflow.keras.preprocessing.image import img_to_array
from tensorflow.keras.models import load_model
from imutils.video import VideoStream
import numpy as np
import argparse
import imutils
import time
import cv2
import os
!pip install telepot
import telepot
!pip install play sound
from playsound import playsound

telegram_bot = telepot.Bot('1863397795:AAHIefQAq-IKGoyP7n8zMwBuzdKG-ZJfZ5c')

global chat_id,msg,my_token

def detect_and_predict_mask(frame, faceNet, maskNet):
	global chat_id, msg, my_token
	(h, w) = frame.shape[:2]
	blob = cv2.dnn.blobFromImage(frame, 1.0, (300, 300),
		(104.0, 177.0, 123.0))
	faceNet.setInput(blob)
	detections = faceNet.forward()

	faces = []
	loc = []
	prediction = []

	for i in range(0, detections.shape[2]):
		confidence = detections[0, 0, i, 2]

		if confidence > args["confidence"]:
			box = detections[0, 0, i, 3:7] * np.array([w, h, w, h])
			(startX, startY, endX, endY) = box.astype("int")
			(startX, startY) = (max(0, startX), max(0, startY))
			(endX, endY) = (min(w - 1, endX), min(h - 1, endY))

			face = frame[startY:endY, startX:endX]
			face = cv2.cvtColor(face, cv2.COLOR_BGR2RGB)
			face = cv2.resize(face, (224, 224))
			face = img_to_array(face)
			face = preprocess_input(face)
			face = np.expand_dims(face, axis=0)

			faces.append(face)
			loc.append((startX, startY, endX, endY))

	if len(faces) > 0:
		prediction = maskNet.predict(faces)
	return (loc, prediction)

ap = argparse.ArgumentParser()
ap.add_argument("-f", "--face", type=str,
	default="face_detector",
	help="path to face detector model directory")
ap.add_argument("-m", "--model", type=str,
	default="mask_detector.model",
	help="path to trained face mask detector model")
ap.add_argument("-c", "--confidence", type=float, default=0.5,
	help="minimum probability to filter weak detections")
args = vars(ap.parse_args())
print("[INFO] loading face detector model...")
prototxtPath = os.path.sep.join([args["face"], "deploy.prototxt"])
weightsPath = os.path.sep.join([args["face"],
	"res10_300x300_ssd_iter_140000.caffemodel"])
faceNet = cv2.dnn.readNet(prototxtPath, weightsPath)

print("[INFO] loading face mask detector model...")
maskNet = load_model(args["model"])

print("[INFO] starting video stream...")
vs = VideoStream(src=0).start()
time.sleep(2.0)

def send():
	global chat_id,msg,my_token
	telegram_bot.sendMessage(chat_id,str(msg))


while True:
	frame = vs.read()
	frame = imutils.resize(frame, width=400)

	(locs, prediction) = detect_and_predict_mask(frame, faceNet, maskNet)
	my_token = '1863397795:AAHIefQAq-IKGoyP7n8zMwBuzdKG-ZJfZ5c'
	chat_id = 1772754880
	msg = "Terdeteksi tidak memakai masker"
	for (box, pred) in zip(locs, prediction):
		(startX, startY, endX, endY) = box
		(mask, withoutMask) = pred

		label = "Bermasker" if mask > withoutMask else "Tidak Bermasker"
		if(label=="Bermasker"):
			color=(0, 255, 0)
		else:
			color=(0, 0, 255)
			playsound('oke.mp3')
			send()
		label = "{}: {:.2f}%".format(label, max(mask, withoutMask) * 100)

		cv2.putText(frame, label, (startX, startY - 10),
			cv2.FONT_HERSHEY_SIMPLEX, 0.45, color, 2)
		cv2.rectangle(frame, (startX, startY), (endX, endY), color, 2)

	cv2.imshow("Frame", frame)
	key = cv2.waitKey(1) & 0xFF

	if key == ord("q"):
		break

cv2.destroyAllWindows()
vs.stop()

